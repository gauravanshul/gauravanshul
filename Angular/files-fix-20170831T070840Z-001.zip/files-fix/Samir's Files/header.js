angular
    .module('goldenpi')
    .controller('HeaderController', ['$scope', '$rootScope', 'AuthService', '$state',
        function ($scope, $rootScope, AuthService, $state) {
            $scope.mainMenuVisible = "none";
            $scope.userIconClicked = false;
            $scope.showHideMainMenu = function () {
                $scope.userIconClicked = !$scope.userIconClicked;
                $scope.userIconClicked === true ? $scope.mainMenuVisible = "block" : $scope.mainMenuVisible = "none";
            }
        }]);